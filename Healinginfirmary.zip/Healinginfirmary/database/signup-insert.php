<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "infirmary_signup_record";
$name= $_POST['name'];
$email= $_POST['email'];
$phone= $_POST['phone'];
$date= $_POST['date'];
$address= $_POST['address'];
$message= $_POST['message'];

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

$sql = "INSERT INTO signup (name,email,phone,active_hour,address,message) 
VALUES('$name','$email',$phone,'$date','$address','$message')";


if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
header('Location:../thank-you.html'); 
?>
